// JavaScript Document




    $('.banner ul').slick({
    dots: true,
    infinite: true,
    speed: 300,
    autoplay:true,
    arrows:false
    });



        $('.dines ul').slick({
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            responsive: [
                {
                  breakpoint: 1200,
                  settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                  }
                },
                {
                  breakpoint: 800,
                  settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                  }
                },
                {
                  breakpoint: 480,
                  settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                  }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
              ]
        });



var scrollState = 'top';


$(window).scroll(function(){ 

    var scrollPos = $(window).scrollTop();
	
    if( ( scrollPos != 0 ) && ( scrollPos > 90 ) && ( scrollState === 'top' ) ) {
        	
			$("header").addClass("scrolled");
			$(".logo").addClass("logo-small");
			
			
		
			scrollState = 'scrolled';
			

			
			
    }       
    else if( ( scrollPos < 90) && ( scrollState === 'scrolled' ) ) {
		

			$("header").removeClass("scrolled");
			$(".logo").removeClass("logo-small");
				
	
	

			scrollState = 'top';
		

    }
	
	

}); 




  

